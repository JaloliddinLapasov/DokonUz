namespace DokonUz.Helpers
{
    public class AuthSettings
    {
        public string? Secret { get; set; }
    }
}
