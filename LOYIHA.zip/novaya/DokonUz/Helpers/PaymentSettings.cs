namespace DokonUz.Helpers
{
    public class PaymentSettings
    {
        public string? SecretKey { get; set; }
    }
}