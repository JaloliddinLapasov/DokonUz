namespace DokonUz.DTOs
{
    public class CategoryCreateDTO
    {
        public string? Name { get; set; }
        public string? Description { get; set; }
    }
}