public enum PaymentStatus
{
    Pending,
    Paid,
    Failed
}
